# Source candidate CI evidence — 2026-10-30 (America/Los_Angeles)

Candidate source/test SHA: `d09c2401839ea5a06fd794c9666d439b17e500e4`, branch `codex/audit-preparation-20261030`, [draft PR34](https://github.com/djshellshoxxx/Unaltered/pull/34). Base/main `da9b0a3626e702381f2ad1d1b1d4cd3128fde2dd`.

Native PR execution checked out synthetic merge `31369ca8e82ca077abdc1dfa8489a30fbe665902`; both commits have exactly tree `063f20dd792428ad05667a45c493ef1ded0c38b5` (verified locally with `git rev-parse <sha>^{tree}`). [CI run41171752457](https://github.com/djshellshoxxx/Unaltered/actions/runs/41171752457), attempt1. This evidence applies to that source tree. A later documentation commit requires its own SHA/run status.

## Current result and limits

**10 of11 required Actions jobs passed; the required native cross-platform comparison job124451539616 remains queued.** The aggregate run is still queued with no conclusion, consistently with that pending job. A request for its log returned GitHub404 BlobNotFound because no log was available. Do not call that native job passed. Independent comparison of all three completed native build artifacts is already successful, as detailed below.

The informational real-browser R1 Alice plus same-receipt reference job passed; the informational live-calendar job failed. The Firefox/WebKit2GiB completion job was skipped by the PR event condition. **SonarCloud Code Analysis failed on this exact source SHA**; Snyk combined commit status is separately successful. Consequently no all-checks-green or completed software acceptance claim is supported.

| Job | Result / inspected evidence |
|---|---|
| [macOS build, tests, and package checksums](https://github.com/djshellshoxxx/Unaltered/actions/runs/41171752457/job/124450996203) | success |
| [End-to-end (firefox, CSP and accessibility)](https://github.com/djshellshoxxx/Unaltered/actions/runs/41171752457/job/124450996367) | success |
| [R1 confirmed upgrade in the browser plus reference verification (informational)](https://github.com/djshellshoxxx/Unaltered/actions/runs/41171752457/job/124450996370) | success |
| [Differential tests against the reference OpenTimestamps client](https://github.com/djshellshoxxx/Unaltered/actions/runs/41171752457/job/124450996380) | success |
| [Live check of calendars and explorers (CORS and API shape, informational)](https://github.com/djshellshoxxx/Unaltered/actions/runs/41171752457/job/124450996392) | failure |
| [End-to-end (webkit, CSP and accessibility)](https://github.com/djshellshoxxx/Unaltered/actions/runs/41171752457/job/124450996395) | success |
| [Identity and metadata leak check](https://github.com/djshellshoxxx/Unaltered/actions/runs/41171752457/job/124450996404) | success |
| [End-to-end (chromium, CSP and accessibility)](https://github.com/djshellshoxxx/Unaltered/actions/runs/41171752457/job/124450996415) | success |
| [Browser 2 GiB memory acceptance (Chromium)](https://github.com/djshellshoxxx/Unaltered/actions/runs/41171752457/job/124450996457) | success |
| [Windows build and tests](https://github.com/djshellshoxxx/Unaltered/actions/runs/41171752457/job/124450996516) | success |
| [Typecheck, lint, unit tests, reproducible build (Linux)](https://github.com/djshellshoxxx/Unaltered/actions/runs/41171752457/job/124450996543) | success |
| [Secret scan (verified Gitleaks release)](https://github.com/djshellshoxxx/Unaltered/actions/runs/41171752457/job/124450996552) | success |
| [Browser 2 GiB completion (${{ matrix.browser }})](https://github.com/djshellshoxxx/Unaltered/actions/runs/41171752457/job/124450996964) | skipped |
| [Linux, Windows, and macOS builds are byte-identical](https://github.com/djshellshoxxx/Unaltered/actions/runs/41171752457/job/124451539616) | queued |

## Browser, memory and reference details

- Chromium156.0.8078.4, Firefox157.0 and WebKit27.2 on Ubuntu26.04.1: each61 passes and1 optional2GiB skip. Windows Server2025/10.0.26100 Chromium156:61 passes and1 optional skip. Inspected all four complete browser job logs; zero failure/retry/flaky markers. The run and every returned job are attempt1; ordinary CI config permits one retry, but none occurred in these logs.
- Native Chromium real-file2GiB:3/3, `--repeat-each=3 --retries=0 --max-failures=1`; digest visible at30.165/29.983/30.026s, maximum sampled extra renderer RSS42,475,520bytes (40.51MiB). Gate unchanged:540s, extra RSS<200MiB, independent digest and worker required. Firefox/WebKit completion remains unexecuted natively by this PR, and there is no Firefox/WebKit memory-ceiling evidence.
- Linux source unit suite172 passes/2 optional skips; Windows/macOS170 passes/4 skips (two additional Unix regular-file tests are platform-specific). macOS26.6.2 native package checksums all five OK. Linux builds twice with build id`f56566235e06e0b4`; source provenance139 verified registry signatures and58 verified attestations. `npm ci` reports11 moderate vulnerabilities in the unchanged lockfile; signature success is not a vulnerability clearance.
- Native Python differential job:18 offline toolkit regressions pass; OpenTimestamps0.4.5 installed, fixture regeneration comparison succeeds;21 codec/differential tests pass. Python3.12.15. Source OPSEC and verified Gitleaks jobs pass.
- [R1 job124450996370](https://github.com/djshellshoxxx/Unaltered/actions/runs/41171752457/job/124450996370):real Chromium156.0.8078.4 app, normal CSP, no route mocks. Alice upgrade200/ACAO`*`, new upgraded receipt downloaded, app VERIFIED block428648, zero CSP violations. Both explorers200/ACAO`*`. The subsequent Python reference verification on **that same downloaded receipt** returns`digestMatches=true`, `ok=true`, `verifiedTime=1473227803`, block428648; independent header sourceblockchain.info. This closes the Alice path for this source/Chromium only; Bob/Finney confirmed paths, pending404 CORS, own-node and broader browser live acceptance remain open.

## Three native artifact identities and independent payload comparison

Downloaded the Linux, Windows and macOS run artifacts through the GitHub connector, materialized via `download_file`, and checked each whole ZIP SHA-256 against its API digest. All five distributable payloads in every artifact are byte-identical to `/workspace/Unaltered/dist` (15 comparisons), and both manifest copies per artifact equal local `dist/SHA256SUMS` (six comparisons). The outer artifact ZIPs differ in archive metadata; their contained distributables match exactly. This is completed independent artifact comparison, separate from the still-queued native comparison job.

| Native artifact | GitHub artifact ID | Bytes | Archive SHA-256 |
|---|---:|---:|---|
| `unaltered-linux-build` | 13031123873 | 304099 | `sha256:40403583a62cc0a06588bc380342c103e544ddfb70713e3b5125a77924088bae` |
| `unaltered-windows-build` | 13030809644 | 304103 | `sha256:6d8f4220a64f1894c503bb4ab18b91b363b737b38cc9350c3e38e9c92e9d7e64` |
| `unaltered-macos-build` | 13030729844 | 304099 | `sha256:4262870693d94e53f00e24e144d1c8e408b49942c90157a033196803fa192971` |

Payload checksums (all three native builds equal the local double build):

```text
35e33bf657d63ccd9b3dd2b24655eb89f26686c92e12787116c3785df6b45dd1  unaltered-0.3.1-macos.zip
36e4c1b92201b242fc1232e2441d6fbd1eaf9ae8020b0e83dded1d69fe757375  unaltered-0.3.1.zip
37930af11f66e1434c17cd78a1c8ff2d97efe147e1bc2553216aa726ee9579ec  unaltered-cli-0.3.1.mjs
a1acf2b541e7fb2c0d4f7ceb48d8eec15c327e441f17b02d979e7ac3ae86f946  unaltered-0.3.1-linux.tar.gz
ec417a90de7e2fba2329e50aa233241cf821987dcb8918bdce718bc0a1ec0fb7  unaltered-0.3.1.html
```

Artifact API metadata associates each with source headd09c240 and run41171752457; expires2027-01-29. Full comparisons are in `source-artifact-comparison.json`; downloaded ZIPs retained in this scratch directory.

## Current Sonar failure: primary GitHub check evidence

[Source check124451150596](https://github.com/djshellshoxxx/Unaltered/runs/124451150596) has `head_sha=d09c2401839ea5a06fd794c9666d439b17e500e4`, statuscompleted, conclusionfailure, title**Quality Gate failed**, annotations_count1. The full check list was readable with the GitHub connector at:

`GET /repos/djshellshoxxx/Unaltered/commits/d09c2401839ea5a06fd794c9666d439b17e500e4/check-runs?per_page=100`

It reports **C Security Rating on New Code (required ≥ A)**. Direct issue link: https://sonarcloud.io/project/issues?id=djshellshoxxx_Unaltered&pullRequest=34&issueStatuses=OPEN,CONFIRMED&sinceLeakPeriod=true . Dashboard: https://sonarcloud.io/dashboard?id=djshellshoxxx_Unaltered&pullRequest=34 .

The annotation API URL is rejected by the connector with HTTP400 `INVALID_ARGUMENT` (“not an allowed public GitHub repository or search endpoint”): `https://api.github.com/repos/djshellshoxxx/Unaltered/check-runs/124451150596/annotations`. The public GitHub check-page URL was also rejected by the connector, but normal `curl --fail --location` through the inherited HTTPS proxy retrieved it with TLS verification enabled. The page embeds the concrete annotation: **`.github/workflows/ci.yml:175` — “Define exact package version to avoid installing unverified releases.”** Source line175 is `npx playwright test tests/e2e/memory.spec.ts --repeat-each=3 --retries=0 --max-failures=1`. Exact issue: [AaGQYYND7JDpWu2qm6wg](https://sonarcloud.io/project/issues?id=djshellshoxxx_Unaltered&issues=AaGQYYND7JDpWu2qm6wg&open=AaGQYYND7JDpWu2qm6wg&pullRequest=34). `npm ci --ignore-scripts` precedes this command and the lockfile pins `@playwright/test`1.64.1, so the normal command resolves the installed CLI. However `npx` can fetch implicitly if that dependency is absent. Recommended narrow correction: use the directly installed CLI path, which fails closed without an implicit install fallback. The integrator owns that correction and final-source validation. Full HTML/text saved as `source-sonar-github-check.html`/`.txt`. There was no network-policy bypass, Sonar request or bot-review trigger. There are zero PR34 inline review threads.

Owner/developer next action: inspect the annotation above and use the installed CLI directly, then validate the resulting source and obtain a fresh exact-SHA Sonar result, or document a reviewed false-positive determination. Do not suppress or assume resolved because Snyk/Actions pass. CodeRabbit skipped automatic review because PR34 is draft; no manual review was triggered.

Full [Sonar comment](https://github.com/djshellshoxxx/Unaltered/pull/34#issuecomment-6539446027), preserved verbatim:

## [![Quality Gate Failed](https://sonarsource.github.io/sonarcloud-github-static-resources/v2/checks/QualityGateBadge/qg-failed-20px.png 'Quality Gate Failed')](https://sonarcloud.io/dashboard?id=djshellshoxxx_Unaltered&pullRequest=34) **Quality Gate failed**  
Failed conditions  
![](https://sonarsource.github.io/sonarcloud-github-static-resources/v2/common/failed-16px.png '') [C Security Rating on New Code](https://sonarcloud.io/project/issues?id=djshellshoxxx_Unaltered&pullRequest=34&issueStatuses=OPEN,CONFIRMED&sinceLeakPeriod=true) (required ≥ A)  
  
<!-- sqra:qg_revision=d368b97601706ad38374d40dc7981d7a58a00100e653ea42524bfc6491203ecb -->
<!-- sqra-placement-anchor -->
[See analysis details on SonarQube Cloud](https://sonarcloud.io/dashboard?id=djshellshoxxx_Unaltered&pullRequest=34)

##   
![](https://sonarsource.github.io/sonarcloud-github-static-resources/v2/common/light_bulb-16px.png '') Catch issues before they fail your Quality Gate with our IDE extension ![](https://sonarsource.github.io/sonarcloud-github-static-resources/v2/common/sonarlint-16px.png '') [SonarQube for IDE](https://www.sonarsource.com/products/sonarlint/features/connected-mode/?referrer=pull-request)



## Recovery commands / pending native job

```sh
gh api repos/djshellshoxxx/Unaltered/actions/runs/41171752457/jobs --jq ' .jobs[] | {id,name,status,conclusion} '
gh run view 41171752457 --repo djshellshoxxx/Unaltered --job 124451539616 --log
gh api repos/djshellshoxxx/Unaltered/check-runs/124451150596/annotations
```

Use an already authorized network/identity; no new credentials are needed for this handoff. When the native comparison completes, preserve its actual log and conclusion. Recheck final documentation SHA separately and retain this source record as historical evidence.

Companion machine-readable evidence: `source-ci-evidence.json`; exact artifact comparison: `source-artifact-comparison.json`; source job logs with SHA-256 identities listed in the JSON. This worker made no code, index, branch, PR, release or account changes.
