# Tooling, reference and security acceptance — consolidation 2026-10-30

Session date is 2026-10-30 America/Los_Angeles; logs use UTC 2026-10-31. Root owns the integration branch, final candidate SHA, browser runs and committed handoff. This worker changed no tracked files. Working tests were run from the clean-base-derived integration checkout while the root imported PR tests; base SHA: `da9b0a3626e702381f2ad1d1b1d4cd3128fde2dd`. Final SHA source identities must be reconciled before claiming final-candidate evidence.

## Platform and verified setup

- Linux x86_64 kernel6.18.57, glibc2.41, Debian trixie. Python3.12.14.
- Node22.22.0 / npm10.9.4 installed under `/workspace/work/unaltered/tools/node-v22.22.0-linux-x64/bin`; official Node archive verified against nodejs.org/v22.22.0/SHASUMS256.txt (not a signed independent provenance attestation).
- OpenTimestamps reference venv: `/workspace/work/unaltered/ots-reference/bin/python`; exact `opentimestamps==0.4.5`; transitive `pycryptodomex==3.24.1`, `python-bitcoinlib==0.12.2`. Install log `reference-install.log`.
- Gitleaks8.30.1: `/workspace/work/unaltered/tools/gitleaks`; release archive SHA256 `551f6fc83ea457d62a0d98237cbad105af8d557003051f41f3e7ca7b3f2470eb` matches the repository CI-pinned digest before extraction/execution. Downloaded through inherited proxy from official gitleaks release.
- `/opt/pw-browsers` and ms-playwright caches absent initially; system Chromium154.0.8037.57 at `/usr/bin/chromium` is available. Pinned engines/install/tests owned by root; this system engine inventory is not pinned Playwright acceptance.
- Network policy read from `/etc/codex/network-policy.json`: restricted HTTP allowlist, no VPN. No credentials/settings/network policy changed. Shell calls requiring sockets/subprocess behavior must use the harness's additional network permission; inherited proxy/CA retained.

## Results

| Gate | Result and exact log |
|---|---|
| `npm ci --ignore-scripts` | Root reports PASS,139 packages, Node22, `npm_config_cache=/workspace/work/unaltered/npm-cache`; initial default home-cache attempt failed unwritable path. Root retains install log. No lockfile/dependency change by this worker. |
| Python toolkit | PASS18/18; `toolkit-unittest-network.log`. Command `PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests/toolkit -p 'test_*.py' -v` (first successful command omitted bytecode flag; generated pycache removed). Offline synthetic SDK mocks only, no paid usage. Two accidental overlapping default-sandbox runs were stopped after loopback/async failures and replaced with one correctly permitted run; they are not passes and are preserved in `toolkit-unittest.log` / `toolkit-unittest-second.log`. No test retry or source change. |
| Reference fixture regeneration | PASS: `ots-reference/bin/python tests/differential/gen_fixtures.py /workspace/work/unaltered/fixtures`; `cmp` each pending/confirmed/batch0/batch1/batch2/litecoin `.ots` and `expected.json` against tracked fixtures. All seven files byte-identical. `fixture-generation.log`; manifests below. |
| Reference differential | PASS21/21 `UNALTERED_PYTHON=/workspace/work/unaltered/ots-reference/bin/python npx --no-install vitest run tests/unit/codec.test.ts`, Node22 and workspace npm cache, additional network permission; `reference-codec-network.log`. Oracle actually ran. First default-sandbox attempt had20 pass/1 fail at Python `spawnSync EPERM` (`reference-codec.log`); not attributed to product and not hidden. |
| Source secret scan | PASS Gitleaks `dir --redact --no-banner` against a tar snapshot of every `git ls-files` path;4.67MB scanned, no leaks. `gitleaks-tracked.log`, `gitleaks-tracked.json`. Earlier four-positional-path command was ambiguous, so replaced by exhaustive tracked snapshot, not counted as gate. Final changed tracked content must be rescanned after root finishes. |
| Fetched history secret scan | PASS Gitleaks `git --redact --no-banner --log-opts='--all' .`;78 non-merge commits scanned across all fetched refs (103 commits including merges),5.06MB,no leaks. Debug log confirms `git -C . log -p -U0 --all`. `gitleaks-all-fetched.log`/`.json`; earlier `gitleaks-history.log` also passes. This was before final integration commit; final range scan still due after root gives final SHA. |
| Dependency vulnerabilities | FAIL `npm audit --json`:11 moderate,0 high/critical. All11 are propagation from dev-only `minimatch@10.2.6` advisory GHSA-g3hv-75wg-m249 (<11.0.1), globparts amplification DoS, affecting eslint/typescript-eslint dependency paths. `npm-audit.json` is authoritative report. `npm audit --omit=dev --json` PASS0 vulnerabilities (`npm-audit-runtime.json`). Runtime noble is not in affected paths. No `npm audit fix` run; suggested destructive eslint4/typescript-eslint downgrades are unsuitable. Root must explicitly defer this with exposure review or make a reviewed compatible dependency change. The checked-in ESLint globs are static and dev-only; this narrows exposure but does not erase the advisory. |
| Actions pins | PASS: all five unique `actions/*@<40hex>` refs in CI and release workflows resolved to the same official repository version-tag target with `git ls-remote`; `action-pins.json`. This proves the refreshed tag mapping, not trust in action code behavior. |
| Registry signatures/provenance | BLOCKED `npm audit signatures` exit1, TUF metadata download HTTP403; `npm-audit-signatures.log`, npm debug log2026-10-31T05_02_46_717Z. npm10.9.4 `@sigstore/tuf` default mirror is `https://tuf-repo-cdn.sigstore.dev`; direct inherited-proxy probe returned403. No TLS/trust bypass/cache fabrication performed. This is not a successful provenance gate. |
| Cross-platform | Not runnable in this Linux-only worker. Root must verify exact final SHA Actions Windows/macOS/Linux results and checksum comparison. Older branch/main CI cannot be attributed to candidate. |

### Reference fixture identities

```
68c38dfc5053cff7bf3c2b27c1ff00dfe48399d7517e25cab4a78584024fe5f3  batch0.ots
ccf927b8a24e74ba9c6296a108966f882409cafb7d7a9fe64406695ac2351406  batch1.ots
2111fc17329a7802d5344910b9532a6ab7375226c3e95f2bd8d4ac8a127826db  batch2.ots
449c0d41d87108f98af2c78f0aa9329a5c13fea7f225530fe37be8976e5b95cc  confirmed.ots
a7684556d9a6582ff2619f55bc604e4595ac1972174914f780c101cf999bf038  expected.json
f8132968fdfc029a288b8e95a23386d748b03d66d9c6755ef9b1b6247ea238f8  litecoin.ots
57a7bb18cd559b5aff136a387116bd1234517c5bf3abe4134b58f605a905210d  pending.ots
```

## R1 preparation and blockers

Documented upstream public inputs downloaded from `raw.githubusercontent.com/opentimestamps/opentimestamps-client/master/examples` into `/workspace/work/unaltered/r1/`. Both SHA256 checks pass:

```
05c4f616a8e5310d19d938cfd769864d7f4ccdc2ca8b479b10af83564b097af9  incomplete.txt
95673f2878cbcfdddded530bd2ad5f3fb04e13d2e659760d7c1386346fdd036c  incomplete.txt.ots
```

Root owns `node scripts/r1-acceptance.mjs` on the candidate browser build. Independent third-source header prep (`curl --fail https://blockchain.info/block-height/428648?format=json`) returns403 from envoy through inherited proxy (`r1/independent-header-fetch.log`, `r1/independent-header-headers.txt`); destination is outside selected policy. No header obtained and no independent verification on a candidate-downloaded receipt can be claimed. Do not use a different receipt to close R1, do not bypass proxy or weaken CSP/CORS. Pending source input is public/synthetic upstream and remains scratch, not committed.

## Smallest next executable actions / owners

- Root/integrator: supply final SHA; run final outgoing Gitleaks range and final tracked snapshot; reconcile test file hashes and record source identity.
- Maintainer/dependency reviewer: assess GHSA-g3hv-75wg-m249 for current fixed developer globs; review a compatible upstream minimatch patch/diff and lockfile integrity before any update. Keep this advisory explicit if no update is included.
- Environment owner: using supported configuration workflow, permit current Sigstore TUF metadata host (or run on approved CI/native environment); then `PATH=/workspace/work/unaltered/tools/node-v22.22.0-linux-x64/bin:$PATH npm_config_cache=/workspace/work/unaltered/npm-cache npm audit signatures`. Never edit policy snapshot, disable TLS or suppress provenance errors.
- Native CI/maintainer: run `.github/workflows/ci.yml` on final candidate ref, inspect exact run SHA and every job; use workflow_dispatch to run Firefox/WebKit2GiB jobs that exclude pull_request. This is CI only, not release workflow.
- Network-capable acceptance operator: reproduce `docs/R1_ACCEPTANCE.md` on candidate with uninspected permitted calendar/explorer/independent-header reachability; `node scripts/r1-acceptance.mjs /workspace/work/unaltered/r1/incomplete.txt /workspace/work/unaltered/r1/incomplete.txt.ots /workspace/work/unaltered/r1/out`, obtain independent header from own node or approved blockchain.info route, then `ots-reference/bin/python tests/differential/verify_reference.py <same-file> <same-browser-downloaded-receipt> <header-hex>`. R1 stays open until both succeed. Alice evidence alone does not establish Bob/Finney browser upgrades.
