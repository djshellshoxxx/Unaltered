# Hash consolidation review — 2026-10-30 client date

Read-only reviewer: `/root/hash_review`. No production, unit-test, index, branch or commit writes were made by this reviewer. Root owns integration and full acceptance. All reviewer scripts and proposed patches are under `work/unaltered/hash-review/`.

## Reviewed inputs and overlap decision

- Refreshed main: `da9b0a3626e702381f2ad1d1b1d4cd3128fde2dd`.
- PR25: `origin/claude/friendly-faraday-papf5c`, `c4723d4974fd03c2adbe3f0a99b4bfe30b865a49`.
- PR31: `origin/claude/hash-stall-progress`, `0d4f465652d86bdfd41ee73447b4ce93e3be818f`.
- Scope: `src/core/hash/{stream,hasher,hasher.worker}.ts`, hashing unit tests, browser memory spec/diagnostics, related CI job and request requirements. Review is internal preparation, not independent human audit acceptance.

Use PR25's implementation as the primary source: remove full-chunk BYOB `min` only for Blob slices, hash partial bytes immediately, account `done` immediately, reopen from `done`, and report/yield per accumulated chunk. Keep existing generic-stream `{min}` behavior, bounded slice size, buffer reuse and EOF checks. PR25 adds the mid-chunk resume regression absent in PR31. Keep PR31's stronger STALL_MS documentation and full slow-trickle test asserting `[3,6,7]` progress. Do not apply both implementations.

A separate cadence regression exercises 11 bytes, 3-byte chunks, one-byte partial reads and a stall at absolute byte 4. Correct slice opens are `[[0,3],[3,6],[4,6],[6,9],[9,11]]`; progress is `[3,6,9,11]`, with four yields. It passes the selected PR25 implementation and confirms reopened slices do not shift cadence or duplicate bytes.

## Demonstrated cancellation boundary defect and fix

Exact PR25 stream plus unchanged main hasher returned success after cancellation in four controlled cases:

1. Abort from the final progress callback in main-thread fallback.
2. Cancellation during the awaited final data read.
3. Cancellation during the awaited final EOF read.
4. Abort during a completed WebCrypto cross-check.

All four failed expected cancellation assertions before the proposed patch. Polling `isCancelled` after data/slice/EOF awaits and yield, before the digest, plus signal checks around `hashBlob`'s cross-check, makes all four pass. No digest may escape after cancellation is observed at those boundaries. Root imported the regressions and minimal fix; root's own Vitest RED/GREEN logs are the authoritative integration evidence.

Reviewer artifacts:

- `hash-review/repro.ts`, isolated source copies in `hash-review/core/`.
- `hash-review/repro-before.log`: four cancellation failures and cadence pass on unmodified PR25/main source.
- `hash-review/repro-after.log`: five passes with proposed boundary fix (host Node24.19.0).
- `hash-review/repro-node22.log`: all five pass using downloaded, verified Node22.22.0.
- `hash-review/cancellation-tests.patch` and `hash-review/cancellation.patch`: proposed test/product patches; root applied them independently.

## Demonstrated retention budget defect and mitigation

The consecutive stall counter resets on every delivered byte. Therefore PR31's prose claim that only MAX_STALLS=3 buffers can be retained globally was false. A delayed native-backend model alternates delivered bytes and silent reads while previous cancellations never complete. On selected source before the budget fix, hashing 33 bytes abandoned 32 readers retaining 32×4MiB = 134217728 bytes. This is a deliberately controlled backend model; it is not a reproduced real-browser RSS failure.

The proposed small fix tracks abandoned **data** readers until cancellation fulfills, retaining the count if cancellation rejects. It refuses with typed `INPUT_UNREADABLE` when three such readers exist, before allocating/opening a fourth hashing buffer. Delivered-byte progress still resets the consecutive-silence counter, and fulfilled cancellation releases the global budget, allowing more than three progress/retry cycles over a file. This mitigates a backend that hangs or fails teardown; it assumes fulfilled cancellation means teardown completed. A faulty backend that fulfills cancellation while retaining memory remains outside that accounting guarantee.

The final EOF probe uses its own one-byte view; it does not transfer the reusable full hashing buffer. EOF-only abandonment is excluded from the full-buffer budget. A regression permits five uncooperative EOF cancellations while preserving correct digest and slice boundaries. This does not claim all backend bookkeeping or one-byte EOF-reader resources are globally bounded independently of file length.

Reviewer artifacts and exact modeled results:

- `hash-review/retention-before-node22.log`: selected source with pending cancellations, 32 abandoned reads, 134217728 retained buffer bytes, successful 33-byte hash.
- `hash-review/retention-node22.log`: proposed budget fix, `INPUT_UNREADABLE` at 3 abandoned reads, 12582912 retained buffer bytes.
- `hash-review/retention-regressions-before-node22.log`: pending and rejected cancellation budget assertions fail; completed-cancellation retry case passes.
- `hash-review/retention-regressions-node22.log`: all three cases pass.
- `hash-review/retention-product.patch`, `hash-review/retention-tests.patch`: root imported and reran. Root increased test-only stallMs from 5 to 20ms for timing margin without changing the 30 s production timeout or acceptance thresholds.

Node22 review commands, after generating scratch bundles with the installed locked esbuild:

```bash
node_modules/.bin/esbuild /workspace/work/unaltered/hash-review/retention-regressions-before.ts /workspace/work/unaltered/hash-review/retention-regressions.ts /workspace/work/unaltered/hash-review/retention-before.ts /workspace/work/unaltered/hash-review/retention.ts /workspace/work/unaltered/hash-review/repro.ts --bundle --platform=node --format=esm --outdir=/workspace/work/unaltered/hash-review/bundled
/workspace/work/unaltered/tools/node-v22.22.0-linux-x64/bin/node /workspace/work/unaltered/hash-review/bundled/retention-regressions-before.js
/workspace/work/unaltered/tools/node-v22.22.0-linux-x64/bin/node /workspace/work/unaltered/hash-review/bundled/retention-regressions.js
/workspace/work/unaltered/tools/node-v22.22.0-linux-x64/bin/node /workspace/work/unaltered/hash-review/bundled/retention-before.js
/workspace/work/unaltered/tools/node-v22.22.0-linux-x64/bin/node /workspace/work/unaltered/hash-review/bundled/retention.js
/workspace/work/unaltered/tools/node-v22.22.0-linux-x64/bin/node /workspace/work/unaltered/hash-review/bundled/repro.js
```

These scratch bundles deliberately freeze before/after sources. The root candidate's frozen source/test SHA and root unit/browser logs must be used for acceptance, not these reviewer snapshots.

## Residual cancellation limitations — explicitly deferred by root

Worker cancellation terminates the worker immediately. The main-thread fallback still polls a callback; it cannot interrupt a native read that has not settled. For the Blob BYOB path, cancellation may wait for the current 30 s silence watchdog and then up to 1 s cleanup. The boundary fix prevents a successful result when control returns and cancellation is observed; it is not an immediate-abort guarantee while a native read remains pending.

For files up to 64 MiB, `readCrossCheckInput` separately uses bounded `slice.arrayBuffer()` reads without watchdog or AbortSignal. A controlled never-resolving cross-check read demonstrates that main-thread fallback can remain pending after abort. With the boundary fixes already present, `crosscheck-pending.ts` produced `{"enteredCrossCheck":true,"aborted":true,"result":"HUNG_AFTER_ABORT"}` under Node22.22.0 (`hash-review/crosscheck-pending.log`). The same limitation predates the selected PR work; no native reproduction has been established. Root explicitly deferred expansion into a new cross-check cancellation design to keep this candidate stable for required gates. Owner: independent auditor/developer. Smallest next action: reproduce with a real stalled small-file backend, then design an abortable bounded cross-check read with a regression and rerun relevant memory/browser acceptance. Do not describe fallback cancellation as universally immediate or complete.

## Browser acceptance boundaries

- Preserve 50 ms responsiveness, Chromium extra renderer RSS <200MiB, and 540 s digest deadline.
- Firefox/WebKit real 2 GiB completion checks prove worker use, digest and deadline only. They do not demonstrate the memory ceiling.
- Root corrected PR25's blanket Worker.evaluate catch into the specific unsupported-WebKit branch; Chromium/Firefox diagnostic evaluation failures remain visible.
- A locally passing baseline and candidate cannot establish the native stall was fixed. Native A/B remains required if the baseline stall cannot be reproduced locally.
- No reviewer scratch test substitutes for final-candidate SHA CI, complete artifact comparison, native cross-platform builds or real-browser R1.
