import subprocess,os,json,hashlib,shutil,time
from pathlib import Path
repo=Path('/workspace/Unaltered'); out=Path('/workspace/work/unaltered'); env=os.environ.copy();env.update(PATH=str(out/'tools/node-v22.22.0-linux-x64/bin')+':'+env['PATH'],npm_config_cache=str(out/'npm-cache'),CHROMIUM_PATH='/usr/bin/chromium',PLAYWRIGHT_BROWSERS_PATH=str(out/'pw-browsers'),XDG_CACHE_HOME=str(out/'xdg-cache'),XDG_CONFIG_HOME=str(out/'xdg-config'),UNALTERED_PYTHON=str(out/'ots-reference/bin/python'))
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(); rows=[]
def run(name,args,extra=None):
 print('START '+name,flush=True); start=time.time();e=env| (extra or {})
 with (out/(name+'.log')).open('w') as f:r=subprocess.run(args,cwd=repo,env=e,stdout=f,stderr=subprocess.STDOUT)
 rows.append(dict(name=name,args=args,exit=r.returncode,seconds=round(time.time()-start,3),source_sha=sha,env={k:e[k] for k in ['CHROMIUM_PATH','UNALTERED_PYTHON']},extra_env=extra or {}));(out/'final-results.json').write_text(json.dumps(rows,indent=2)+'\n');print('DONE '+name+' exit='+str(r.returncode),flush=True);return r.returncode
for i in [1,2]:
 if (repo/'dist').exists():shutil.rmtree(repo/'dist')
 assert run('final-build-'+str(i),['npm','run','build'])==0
 dist=repo/'dist';manifest='\n'.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(dist).as_posix() for p in sorted(dist.rglob('*')) if p.is_file())+'\n';(out/('final-build-'+str(i)+'.sums')).write_text(manifest)
 if i==1:shutil.copytree(dist,out/'final-build-1',dirs_exist_ok=True)
assert (out/'final-build-1.sums').read_bytes()==(out/'final-build-2.sums').read_bytes()
run('final-checksums',['sha256sum','--check','SHA256SUMS']) if False else None
with (out/'final-checksums.log').open('w') as f:rc=subprocess.run(['sha256sum','--check','SHA256SUMS'],cwd=repo/'dist',stdout=f,stderr=subprocess.STDOUT).returncode
assert rc==0;print('ALL 10 BUILD FILES IDENTICAL; 5 DISTRIBUTABLE CHECKSUMS PASS',flush=True)
run('final-chromium-e2e',['npx','--no-install','playwright','test','--retries=0','--reporter=list,json'],{'PLAYWRIGHT_JSON_OUTPUT_NAME':str(out/'final-chromium-e2e.json')})
run('final-language-repeat',['npx','--no-install','playwright','test','tests/e2e/language-switch.spec.ts','--repeat-each=3','--retries=0','--reporter=list,json'],{'PLAYWRIGHT_JSON_OUTPUT_NAME':str(out/'final-language-repeat.json')})
run('final-node-2gib',['npx','--no-install','vitest','run','tests/unit/hash.test.ts'],{'UNALTERED_BIG':'1'})
run('final-chromium-2gib',['npx','--no-install','playwright','test','tests/e2e/memory.spec.ts','--repeat-each=3','--retries=0','--max-failures=1','--reporter=list,json'],{'UNALTERED_BIG_BROWSER':'1','PLAYWRIGHT_JSON_OUTPUT_NAME':str(out/'final-chromium-2gib.json')})
run('final-r1-browser',['node','scripts/r1-acceptance.mjs',str(out/'r1/incomplete.txt'),str(out/'r1/incomplete.txt.ots'),str(out/'r1/final-out')])
print('FINAL ACCEPTANCE FINISHED '+sha,flush=True)
