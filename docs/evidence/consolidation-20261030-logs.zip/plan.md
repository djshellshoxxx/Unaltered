# Unaltered audit-preparation consolidation plan

Goal: one reviewable candidate on a new branch from refreshed main, with honest acceptance and full recovery evidence.
Spec: uploaded request, CONTRIBUTING.md, docs/SPEC.md, BUILD_PLAN.md, OPSEC.md, RELEASE.md, R1_ACCEPTANCE.md.

Constraints: preserve existing changes/branches/history; no main merge, force push, release, deployment, credentials, settings or paid APIs. Keep version 0.3.1, pinned dependencies and full-SHA Actions. Keep 50 ms responsiveness, Chromium extra renderer RSS <200 MiB and 540 s completion. Network failures never confirm/verify. Native-only and human gates require actual evidence.

- [x] Refresh main and all 28 remote branch tips; preserve initial clean work branch at da9b0a3. Connector confirms four open PRs. Initial shell fetch failed without network capability; enabling supported per-command capability succeeded.
- [ ] Reconcile every remote branch by ancestry, patch identity and inspection; review discussions/Actions separately from commit statuses. Delegate read-only exhaustive ledger.
- [ ] Import #25 hash tests first, demonstrate regressions on main, then import preferred implementation and memory spec. Reconcile #31's extra progress assertion/comments; investigate actual cancellation/retention defects with regressions. Keep main action pins.
- [ ] Import #30 and #33 tests/helpers first; demonstrate pending notice regression, then apply calendar/UI changes. Check same network helpers preserve upgrades and language state, no repeated hash/submission.
- [ ] Select compatible missing branch diagnostics/docs; leave experiments and unrelated features out with reasons.
- [ ] Install exact locked dependencies with npm ci --ignore-scripts under Node22. Reference venv OpenTimestamps0.4.5; run check/toolkit/reference fixtures/security/dependency/provenance checks.
- [ ] Two clean builds: compare every file and distributable checksums. Full e2e each available engine and seven language cases three times, zero retries. Node/browser2GiB; native A/B where executable. R1 real browser and independent reference same receipt.
- [ ] Independent changed-range review; fix demonstrated important defects and rerun relevant acceptance. Commit source/tests/workflow to freeze tested SHA.
- [ ] Publish only new candidate branch/draft PR if supported, obtain exact-head CI incl manual non-PR Firefox/WebKit job. Never substitute earlier PR results.
- [ ] Prepend authoritative HANDOFF/TODO/COMPLETION_STATUS/NETWORK; preserve dated history. Record exhaustive dispositions, tested SHA/logs/artifact identities, owners/smallest next commands, unsigned status and working tree. Final docs SHA separately from code/test SHA.

Review focus: partial reads crossing chunk boundaries; late abandoned reads changing digest; fallback cancellation while stream is silent; NET_FAILED outage mistaken for CORS; mocks shared by pending and confirmed upgrades.
Ruling: execute supplied specification without an approval pause, as explicitly requested; use clean existing checkout on a new branch rather than create unnecessary nested worktree. Root integrates; read-only workers own branch/hash review and independent tooling checks.
