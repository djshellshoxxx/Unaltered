# Bob/Finney diagnostic review

Read-only review of new diagnostic helpers/CLI/tests and the existing browser-report producer, 2026-10-31. No browser or live service used; no repository files changed.

## Required P2: HTTP 200 alone can falsely establish a confirmed calendar path

Location: `scripts/lib/r1-calendars.mjs:30` and `:42`.

`CONFIRMED_READABLE` requires only status 200, any ACAO value, and no transport failure. The app's parser/proof result for that calendar is ignored. A receipt normally has Alice, Bob and Finney branches. Alice may successfully add Bitcoin data so the whole app run is `PASS`/`VERIFIED`, while Bob returns a readable malformed HTTP 200. `upgrade()` records Bob in its failed-calendar list (`src/core/ots/calendar.ts:180-192`); `r1-acceptance.mjs:64` includes that list in the report. The new helper nevertheless calls Bob `CONFIRMED_READABLE` and reports overall `PASS`. A readable HTTP 200 carrying only pending timestamp data similarly does not establish a confirmed Bob path, and the existing report lacks structured per-calendar Bitcoin-attestation evidence.

Reproduced under Node 22.22.0 by directly importing the pure helper with this report:

```js
{
  classification: 'PASS', verify: { state: 'VERIFIED' }, csp: [],
  upgrade: { downloaded: true, failedCalendars: [
    'bob.btc.calendar.opentimestamps.org – The receipt is damaged or incomplete.'
  ] },
  requests: [{ host: 'bob.btc.calendar.opentimestamps.org', method: 'GET',
    kind: 'upgrade', status: 200, acao: '*' }]
}
```

`classifyCalendars(report, ['bob'])` produced `CONFIRMED_READABLE`; `overall(report, rows)` produced `PASS`.

Minimal direction: fail closed for a target whose app upgrade failed, and distinguish a readable HTTP reply from a successfully parsed confirmed timestamp. Strong evidence needs structured per-calendar parse/Bitcoin-attestation results, or an isolated target-only upgrade followed by verification. The existing test at `tests/r1/r1-calendars.test.mjs:38` checks only status/ACAO plus global classification and would preserve this false positive; add a contradictory per-calendar failure case and pending-only 200 case.

## Uncertainty and scope

No native browser run was attempted. The reported false positive is deterministically demonstrated at the pure classifier boundary; the mixed Alice-success/Bob-parse-failure report follows directly from the existing app and browser-report code, but was not reproduced through a browser here. The offline classifier does not cryptographically bind the supplied receipt to its saved report; its documented workflow relies on the operator supplying the same receipt. That is not a separate blocker for this optional host-compatibility diagnostic.
