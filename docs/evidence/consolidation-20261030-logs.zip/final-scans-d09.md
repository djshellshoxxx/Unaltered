# Final frozen source static/security checks

Source/test/workflow SHA: `d09c2401839ea5a06fd794c9666d439b17e500e4`; branch `codex/audit-preparation-20261030`; base `da9b0a3626e702381f2ad1d1b1d4cd3128fde2dd`. Checked during docs-only handoff editing; docs commit remains to be scanned separately. This worker changed no tracked files.

- PASS outgoing-history Gitleaks8.30.1: `gitleaks git --redact --no-banner --log-opts='da9b0a3626e702381f2ad1d1b1d4cd3128fde2dd..d09c2401839ea5a06fd794c9666d439b17e500e4' --report-format json --report-path /workspace/work/unaltered/gitleaks-outgoing-d09.json .`;1 commit/26.14KB,no leaks. `gitleaks-outgoing-d09.log`, JSON empty.
- PASS source snapshot Gitleaks8.30.1: `git archive d09c2401839ea5a06fd794c9666d439b17e500e4` extracted under `/workspace/work/unaltered/source-d09`, then `gitleaks dir --redact --no-banner`;4.68MB,no leaks. `gitleaks-source-d09.log`, JSON empty. No node_modules/dist or local credentials included; only committed source.
- PASS earlier toolkit/reference result identity: every recorded hash in `tooling-tested-files.sha256` matches the final frozen source checkout (`tooling-file-equivalence-d09.log`). Also `git diff da9b0a3 d09c240 -- src/core/ots/{codec,types,ops}.ts src/core/bytes.ts tests/unit/codec.test.ts tests/differential tests/fixtures/ots tests/toolkit skills/mcp-builder/scripts/evaluation.py skills/webapp-testing/scripts/with_server.py skills/brainstorming/scripts/stop-server.sh shared/scripts package-lock.json` is empty. Earlier18/18 offline Python toolkit,21/21 codec/reference, regenerated6 `.ots` + `expected.json` byte identity therefore cover exactly the same files in d09; no rerun required. Root's full final source suite is separate evidence.
- PASS YAML syntax using already installed PyYAML6.0.3 BaseLoader, custom mapping constructor rejecting duplicate keys: CI12 jobs and release3 jobs parse. Top-level `on` is kept as string (no YAML1.1 boolean misparse). No dependencies installed for this check.
- PASS `bash -n` on all37 Bash CI `run:` blocks and9 Bash release blocks. Eight Windows-only PowerShell blocks remain unparsed because `pwsh` is unavailable. Release matrix commands are simple npm commands checked as Bash for Linux/macOS; no native Windows claim.
- Bounded static controls: all action refs use40-hex SHAs, global permissions `contents: read`, no pull_request_target, CI only push-main/pull_request/workflow_dispatch, release only workflow_dispatch. Chromium and Firefox/WebKit memory commands retain `--repeat-each=3 --retries=0 --max-failures=1` and `UNALTERED_BIG_BROWSER=1`; Firefox/WebKit job still excludes pull_request. `tests/e2e/memory.spec.ts` retains540000ms completion and strict `<200*1024**2` Chromium renderer extra RSS; app responsiveness assertion retains `<50ms`. No retries/thresholds changed by this worker.
- UNAVAILABLE `actionlint`, PowerShell parser: not installed/cached. No workflow-expression/schema/native-shell validity is inferred from YAML/bash parsing. Exact-SHA GitHub Actions/native jobs remain the acceptance gate.

Static report: `/workspace/work/unaltered/workflow-syntax/report.json`; reproducible check script `/workspace/work/unaltered/workflow-syntax/check.py`; summary `/workspace/work/unaltered/workflow-syntax/check.log`.

Workflow identities:

```
6d24f7f15c37abf6e3acf92248a940c09c6c743a24161649cb6a32750779605c  .github/workflows/ci.yml
b8363286689de5de5eb57d8ae73d883df057fc63f05ca354390b70e20fe2a018  .github/workflows/release.yml
3a1826b552900d66219126f0f0028a096cb05a97f5cfa3e7c551d6a4b1120f72  tests/e2e/memory.spec.ts
```

These checks ran without concurrent heavy campaigns/browser execution. Native/R1/provenance/human/signing remaining gates are unchanged; see root's final acceptance ledger. Final handoff/docs source and outgoing-history scan still due after documentation commit.
